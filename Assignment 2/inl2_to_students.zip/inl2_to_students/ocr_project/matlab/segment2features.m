function features = segment2features(I)
% features = segment2features(I)

features = randn(6,1); % not a very useful feature vector...